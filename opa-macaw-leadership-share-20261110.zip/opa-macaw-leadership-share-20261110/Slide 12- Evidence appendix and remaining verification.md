# Slide 12 — Evidence appendix and remaining verification

**The bounded authorization and execution-protection scope is accepted.** The connected D01–D11 design has a broader acceptance surface.

| Scenario | OPA evidence | Macaw evidence |
|---|---|---|
| D01 owned read | Operator-reported Agent Identity success | App balance read, ownership parity pending |
| D02 Reader transfer | Selected synthetic role coverage, connected case pending | App transfer denied |
| D03 Writer $25 | Saved synthetic mutation | Synthetic handler called |
| D04 Writer $150 | Saved synthetic gateway denial | Parameter denial |
| D05 A→B denial | Connected implementation, acceptance pending | Integration pending |
| D06 ownership denial | Saved Agent Identity receiver denial | Pending |
| D07 amount tamper | Saved synthetic mismatch | Pending |
| D08 destination tamper | Saved synthetic mismatch | Pending |
| D09 direct bypass | Saved synthetic proof rejection | Pending |
| D10 same-action/key retry | Saved synthetic idempotency | Pending |
| D11 evaluator unavailable | Saved Agent Identity fail-closed result | Pending |

<!-- Speaker notes -->
Sources were reviewed November 10, 2026. See sources.md for exact artifacts and evidence labels. No live flow was rerun for slide creation.
