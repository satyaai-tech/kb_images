# Slide 2 — Banking use cases express enterprise control requirements

| Business requirement | Banking example | Required outcome |
|---|---|---|
| Respect user authority | Reader requests a transfer | Block execution |
| Apply business limits | Writer requests $25 or $150 with a $100 cap | Allow $25 and deny $150 |
| Protect ownership | Reader requests another user's account | Return no unauthorized data |
| Control agent relationships | Agent A requests Agent B without permission | Block before Agent B |
| Preserve the authorized action | $25 becomes $75 or destination changes after authorization | Reject before mutation |
| Handle bypass, retries and outages | Missing proof, repeated action/key, unavailable evaluator | Reject bypass, avoid duplicate mutation, fail closed |

The connected 11-scenario design covers these requirements. Runtime evidence varies by scenario and implementation.

<!-- Speaker notes -->
Similar requirements apply to Jira updates, service-management changes and data access. Separate-person approval and restricting a Writer to a read-only task are further targets beyond the demonstrated outcomes.
