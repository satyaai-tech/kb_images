# Slide 9 — OPA and Macaw have different demonstrated integration depth

![Leadership comparison](assets/images/entra-solo-opa-macaw-leadership.png)

| Factor | OPA | Macaw |
|---|---|---|
| Evidence | Bounded reads and synthetic amount, tamper, bypass and retry gates | Four standalone SDK outcomes |
| Solo enforcement | Exercised in retained gates | Decision contract pending |
| Action integrity | Custom envelope path exercised | Connected vendor proof path pending |
| Operating ownership | Tachyon integration, OPA policy operations and receiver checks | Tachyon integration plus SDK/workspace dependencies |

No implementation-effort, latency or operating-cost benchmark was collected.

<!-- Speaker notes -->
Benefits in the reused visual are evaluation hypotheses. Existing business ownership and idempotency responsibilities persist. The columns are different integration stages today.
