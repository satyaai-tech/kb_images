# Banking agent controls — leadership story

Markdown draft created November 10, 2026. Slides 1–11 form the main story. Slide 12 is the evidence appendix.

The slide text is followed by speaker notes introduced by an HTML comment. Supporting detail and sources can be relocated when converting to a presentation.

OPA results cover the agreed bounded authorization and execution-protection scope. Macaw has standalone SDK results and pending connected integration. Evidence labels distinguish saved operator-run reports, operator statements, fixtures, documented capabilities and proposed integrations.

1. [Controlling enterprise agent actions](Slide%201-%20Controlling%20enterprise%20agent%20actions.md)
2. [Banking use cases express enterprise control requirements](Slide%202-%20Banking%20use%20cases%20express%20enterprise%20control%20requirements.md)
3. [Common architecture preserves identity through execution](Slide%203-%20Common%20architecture%20preserves%20identity%20through%20execution.md)
4. [OPA separates policy decisions from execution enforcement](Slide%204-%20OPA%20separates%20policy%20decisions%20from%20execution%20enforcement.md)
5. [OPA demonstrates the selected bounded controls](Slide%205-%20OPA%20demonstrates%20the%20selected%20bounded%20controls.md)
6. [Macaw demonstrates standalone SDK policy enforcement](Slide%206-%20Macaw%20demonstrates%20standalone%20SDK%20policy%20enforcement.md)
7. [Macaw connected integration has a defined acceptance gate](Slide%207-%20Macaw%20connected%20integration%20has%20a%20defined%20acceptance%20gate.md)
8. [Macaw value depends on code we can actually retire](Slide%208-%20Macaw%20value%20depends%20on%20code%20we%20can%20actually%20retire.md)
9. [OPA and Macaw have different demonstrated integration depth](Slide%209-%20OPA%20and%20Macaw%20have%20different%20demonstrated%20integration%20depth.md)
10. [Rego Cedar and MAPL express policies with different models](Slide%2010-%20Rego%20Cedar%20and%20MAPL%20express%20policies%20with%20different%20models.md)
11. [Use one enterprise contract and a bounded Macaw decision](Slide%2011-%20Use%20one%20enterprise%20contract%20and%20a%20bounded%20Macaw%20decision.md)
12. [Evidence appendix and remaining verification](Slide%2012-%20Evidence%20appendix%20and%20remaining%20verification.md)

[Evidence and sources](sources.md)

## Sharing package

All slide images and their source prompts are included under assets/. Open this file to navigate the slides. Mermaid diagrams on Slides 4 and 7 require a Markdown viewer with Mermaid support. Local POC evidence is referenced in sources.md and is not bundled.
