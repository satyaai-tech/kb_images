# Slide 4 — OPA separates policy decisions from execution enforcement

**OPA evaluates policy. Solo and Banking enforce the result.**

| Control | Location | Platform work |
|---|---|---|
| User and agent identity | Entra, sidecars and validators | Configure delegated access and validation |
| Tool and amount permission | OPA, enforced by Solo MCP gateway | Supply verified context and arguments to Rego |
| Action integrity | Signed envelope issued in the OPA test path and checked at Banking | Bind identity and action fields to execution |
| Ownership and retry behavior | Banking MCP | Check ownership, confirmation and idempotency |

~~~mermaid
flowchart LR
    W["Validated Writer request"] --> G["Solo MCP PEP"]
    G <-->|Decision and signed envelope| P["OPA + Rego"]
    G --> B["Banking PEP verifies action"]
    B --> S["Synthetic transfer"]
~~~

The connected profile also implements an A2A policy hook. The bounded binding results do not establish full connected A2A acceptance.

<!-- Speaker notes -->
A test hop changes $25 to $75 after OPA signs the authorized request. Banking detects the mismatch. The platform supplies envelope issuance, forwarding and receiver verification.
