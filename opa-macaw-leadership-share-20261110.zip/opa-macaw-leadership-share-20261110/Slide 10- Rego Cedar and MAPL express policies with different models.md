# Slide 10 — Rego Cedar and MAPL express policies with different models

| Dimension | Rego with OPA | Cedar | MAPL with Macaw |
|---|---|---|---|
| Policy model | Rules over structured facts | Principal, action, resource and context | Identity/resource policies and parameter constraints |
| Composition | Explicit rules and data | Permit/forbid, default deny | Vendor-documented hierarchical restriction |
| Banking cap | Evaluate role, scope and trusted limit | Permit transfer under supplied conditions | Constrain amount to maximum 100 |
| Integration | OPA decision API | Embedded engine or hosting service | Macaw SDK/platform |
| POC experience | Implemented | Documentation review only | Standalone policies exercised |
| Portability work | Input schema and built-ins | Entities, context and host API | Macaw policy/runtime contract |

**Language and platform are separate choices.** Signing, approval records, trusted task context and receiver enforcement depend on the surrounding implementation.

<!-- Speaker notes -->
Rego and Cedar can evaluate trusted approval/delegation facts when supplied. Do not repeat vendor claims about other languages as established limitations. Cedar has not been runtime-tested here and no three-way benchmark was performed.

[Rego](https://www.openpolicyagent.org/docs/policy-language), [Cedar](https://docs.cedarpolicy.com/auth/authorization.html), [MAPL](https://www.macawsecurity.com/docs/policies), [MAPL constraints](https://www.macawsecurity.com/docs/policies/constraints)
