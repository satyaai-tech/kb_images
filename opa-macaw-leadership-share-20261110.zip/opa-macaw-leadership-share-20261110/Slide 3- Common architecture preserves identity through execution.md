# Slide 3 — Common architecture preserves identity through execution

![Common agent architecture with Microsoft Entra and neutral components](assets/images/common-agent-architecture-entra-neutral.png)

Microsoft Entra supplies identity and delegated tokens. Generic gateways enforce policy decisions, and the receiving Banking service verifies ownership and execution. Observability spans the flow.

The PDP is a logical role that may have multiple instances. Dashed identity lines indicate trust relationships. This is a reference design, with implementation evidence summarized on the following slides.

**POC implementation and scenario reference**

![Connected Banking flow and scenario design](assets/images/connected-agent-authorization-11-scenarios.png)

Entra establishes user and agent context. Auth sidecars acquire delegated tokens. Solo routes requests and applies gateway controls. Banking checks ownership and protected execution.

**This visual shows the connected test design.** Full D01–D11 connected acceptance remains pending. For D07/D08, “after approval” refers to the test's authorization/confirmation stage. A separate person's approval was not demonstrated.

<!-- Speaker notes -->
The intended route is User → API gateway → Agent A → A2A gateway → Agent B → MCP gateway → Banking. A2A relationship authorization and MCP tool/amount authorization are separate decisions. Standalone transfer gates exercise shorter fixture paths.
