# Slide 1 — Controlling enterprise agent actions

**Banking Agent POC — OPA and Macaw**

A reusable platform should establish who an agent represents, decide what it may do, and protect the business action that executes.

| OPA | Macaw | Enterprise implication |
|---|---|---|
| Bounded OPA controls demonstrated | Four standalone Macaw policy outcomes observed | Standardize Tachyon hooks and evaluate additional vendor value against the working baseline |

Identity and routing foundations are Microsoft Entra and Solo. This review uses synthetic Banking operations.

**Evidence as of November 10, 2026.** OPA combines Agent Identity reads with synthetic transfer and binding gates. Macaw uses Macaw application identities.

<!-- Speaker notes -->
The implementations have different evidence depth and integration coverage. The appendix identifies the boundaries. Proposed platform benefits require additional evidence.
