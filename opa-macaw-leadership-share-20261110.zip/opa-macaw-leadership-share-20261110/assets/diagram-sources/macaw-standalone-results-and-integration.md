# Macaw standalone results and integration — generation prompt

Created 2026-11-10. New AI-generated infographic for the Phase 6/Phase 7 leadership story. Visual review confirmed the four observed standalone outcomes and pending connected integration labels.

Create a clean landscape leadership technical infographic, white background navy text teal and amber accents. Title "Macaw Banking Evaluation". Subtitle "Standalone results and the next integration gate". Large readable labels with simple icons, no real people, no vendor logos required.
Top left broad panel heading "Observed in standalone Docker". Draw two caller boxes "Reader app" and "Writer app", through a central "Macaw SDK + MAPL policies" box to "Synthetic Banking handlers". Small label "Macaw application identities". Under this flow four outcome tiles exactly: "Balance read — ALLOW", "Reader transfer $25 — DENY", "Writer transfer $25 — ALLOW", "Writer transfer $150 — DENY". Bottom of panel "Transfer limit $100 · Denied requests did not reach transfer handler". Make positive allow tiles green and deny tiles red but no checkmarks implying full phase completion.
Bottom broad amber dashed-outline panel heading "Connected integration — pending". Inside left-to-right route "Entra Reader / Writer → Solo gateways → Agent A / B → Banking MCP". Three question chips: "Preserve delegated user identity", "Reject $25 changed to $75", "Verify Macaw proof before execution". Lower line "Vendor contract needed for the existing Solo route".
Footer "Standalone evidence does not establish connected parity or production readiness". Keep content exact and spacious, use landscape 3:2 framing. No claims that Macaw enforces policy at Solo today.

The routes are schematic. The connected flow's full gateway ordering appears on Slide 3. This image illustrates reported evidence rather than a new runtime test.
