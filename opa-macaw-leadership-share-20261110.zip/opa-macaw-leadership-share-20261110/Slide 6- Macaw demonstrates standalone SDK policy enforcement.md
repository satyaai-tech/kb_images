# Slide 6 — Macaw demonstrates standalone SDK policy enforcement

![Macaw standalone results and pending connected integration](assets/images/macaw-standalone-results-and-integration.png)

**Implemented.** Macaw Client 0.9.21 runs in Docker, registers application identities and uses four console policies for Banking, Reader, Writer and transfer limits.

**Observed.** Balance read allowed, Reader transfer denied, Writer $25 allowed, Writer $150 denied. Receiver logs show no transfer-handler invocation for rejected calls.

<!-- Speaker notes -->
This live SDK/workspace test used application identities and synthetic handler results. It did not exercise the existing Entra Reader/Writer OBO route, a ledger, or the full Macaw scenario set.
