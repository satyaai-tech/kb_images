# Slide 8 — Macaw value depends on code we can actually retire

| Candidate value | Acceptance exercise | Current evidence |
|---|---|---|
| Replace custom action-proof plumbing | Authorize $25, deliver $75, reject at Banking | Connected proof path pending |
| Carry reduced task authority | Writer on a balance-review task cannot transfer | Evaluation target |
| Require a distinct approver | Bind another person's approval to one transfer | Vendor-documented attestation capability, POC pending |
| Simplify policy operations | Explain effective restrictions and denial cause | Console policies and denial logs observed, full chain pending |

**Observation.** The standalone Macaw test reproduces basic permission and amount outcomes. Reduced engineering effort and stronger connected workflow protection remain unproven.

<!-- Speaker notes -->
One standard Tachyon hook amortizes OPA integration across agents. Macaw must improve remaining signing, workflow or operational work enough to justify its integration. Attestations motivate an approval test but do not establish exact approval binding here.

[Macaw attestation documentation](https://www.macawsecurity.com/docs/attestations)
