# Slide 11 — Use one enterprise contract and a bounded Macaw decision

**Recommendation.** Continue the OPA baseline and evaluate Macaw against one protected Banking action.

1. Define a Tachyon contract for verified user, agent, task, action and resource context.
2. Maintain SDK hooks for local actions and gateway enforcement for routed calls.
3. Obtain the supported Macaw contract.
4. Test unchanged $25, changed $25→$75 and missing proof through Solo.
5. Expand when evidence supports retiring named code or adding a required control.

| Decision evidence | Measure |
|---|---|
| Equivalent controls | Authorized execution and zero unauthorized mutations |
| Less engineering effort | Specific code retired and integration added |
| Operational fit | Latency, outages, policy rollout, support and cost |
| Enterprise fit | Delegation, ownership and audit across LOB teams |

<!-- Speaker notes -->
Separate-person approvals and read-only task authority can follow if needed. Model Armor and NeMo safety questions are a separate control evaluation from policy-language selection.
