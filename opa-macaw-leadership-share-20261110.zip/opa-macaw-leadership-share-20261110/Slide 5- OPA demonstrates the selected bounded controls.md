# Slide 5 — OPA demonstrates the selected bounded controls

| Observed case | Result | Evidence class |
|---|---|---|
| Owned account read | Allowed | Agent Identity live, operator-reported |
| OPA denial | Zero Banking calls | Saved Agent Identity report |
| OPA unavailable | Zero Banking calls | Saved Agent Identity report |
| OPA allows, ownership fails | One Banking delivery, no unauthorized data | Saved Agent Identity report |
| Writer $25 / $150 | One synthetic mutation / zero deliveries | Saved synthetic OPA report |
| Amount or destination changed | Receiver rejects, zero mutations | Saved synthetic binding report |
| Missing/forged proof and same-action/key retry | Bypass rejected, no duplicate mutation | Saved synthetic binding report |

**Observation.** The bounded tool, amount and action-integrity objectives were accepted as complete on November 4. Integration and operations remain platform responsibilities.

**Boundary.** Transfers use synthetic identities/accounts and floating-point amounts. Full connected D01–D11 acceptance, production readiness and Agent Identity Writer parity are unproven.

<!-- Speaker notes -->
Saved reports substantiate what the operator-run harness recorded. They are not independent observation of the original service execution.
