# Slide 7 — Macaw connected integration has a defined acceptance gate

**Target.** Evaluate Macaw within the existing Entra, Solo, ADK and Banking flow.

~~~mermaid
flowchart LR
    U["Entra Reader / Writer"] --> A["API gateway → Agent A"]
    A --> B["A2A gateway → Agent B"]
    B --> M["Solo MCP gateway"]
    M --> R["Banking MCP"]
    C["Macaw integration candidate"] -. "Supported hook to verify" .-> B
    C -. "Receiver proof to verify" .-> R
~~~

| Open question | What must be shown |
|---|---|
| Solo decisions — MQ-001 | Supported decision-only interface if Solo will enforce Macaw decisions |
| ADK and identity — MQ-002 | Hook preserving original Entra user and calling agent |
| Signed action — MQ-003 | Banking verifies Macaw proof and rejects $25 changed to $75 |

The documented SDK path needs a supported integration contract for this route.

<!-- Speaker notes -->
This gap in reviewed evidence does not establish product-wide incompatibility. Request supported versions and a receiver example. The current handoff is blocked on the contract rather than a connected Macaw runtime failure.
