# Evidence and source register

Reviewed November 10, 2026. No runtime test, authentication or policy deployment was performed for slide creation.

## Local POC records

Source repository is enterprise-agent-poc-starter. Paths below identify internal source records relative to that repository. The records are referenced for provenance and are not bundled in this presentation package.

| Path | Supports |
|---|---|
| evidence/phase-6/index.md, Bounded 6A/6B Closure Matrix | Agreed completion and evidence limits |
| evidence/phase-6/opa-deny-20261103T211400Z.json | OPA denial, zero Banking calls |
| evidence/phase-6/opa-unavailable-20261103T213616Z.json | Evaluator outage, zero Banking calls |
| evidence/phase-6/operator-runs/opa-ownership-deny-20261104T133654Z.json | Ownership denial after OPA allow |
| evidence/phase-6/operator-runs/transfer-amount/transfer-amount-87db0830ef-20261104T181918Z.json | Synthetic amount gate |
| evidence/phase-6/operator-runs/binding/binding-4d6f8c7a23-20261104T212514Z.json | Synthetic tamper, bypass and idempotent retry |
| docs/phase-6-connected-demo.md and evidence index connected section | Scenario design and pending acceptance |
| experiments/macaw/README.md, Operator-reported Docker result — 2026-11-06 | Four app-identity outcomes and receiver logs |
| experiments/macaw/policies/transfer-limit.json and writer.json | MAPL configuration |
| .agent-handoff/status.md and result.md, HANDOFF-014 | Blocked proof-path investigation |
| docs/phase-7-macaw-vendor-questions.md | MQ-001, MQ-002 and MQ-003 |

The retained JSON files above were opened during this review. Owned-read success remains operator-reported without retained JSON, as recorded in the evidence index. Prior synthetic invalid-JWT probing is not evidence of valid Entra acceptance and is excluded from leadership outcomes. Historical unit counts are not tests rerun for this deck.

## Primary documentation

- [OPA policy language](https://www.openpolicyagent.org/docs/policy-language)
- [OPA management](https://www.openpolicyagent.org/docs/management-introduction)
- [Cedar](https://docs.cedarpolicy.com/)
- [Cedar authorization](https://docs.cedarpolicy.com/auth/authorization.html)
- [Cedar validation](https://docs.cedarpolicy.com/policies/validation.html)
- [Macaw platform](https://www.macawsecurity.com/docs)
- [Macaw Client](https://www.macawsecurity.com/docs/api/macaw-client)
- [MAPL](https://www.macawsecurity.com/docs/policies)
- [MAPL constraints](https://www.macawsecurity.com/docs/policies/constraints)
- [Macaw attestations](https://www.macawsecurity.com/docs/attestations)

Language comparison is a documentation review, not a runtime equivalence or performance benchmark. No Cedar implementation was tested.

## Visual register

| Image under assets/images | Use |
|---|---|
| common-agent-architecture-entra-neutral.png | Slide 3, new vendor-neutral logical view retaining Microsoft Entra |
| connected-agent-authorization-11-scenarios.png | Slide 3, reused design, approval wording qualified in text |
| macaw-standalone-results-and-integration.png | Slide 6, new illustration of observed results and pending integration |
| entra-solo-opa-macaw-leadership.png | Slide 9, reused comparison, potential benefits remain evaluation targets |

AI-generated visuals support explanation and do not establish deployment or test results.
